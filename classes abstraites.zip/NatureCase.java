public enum NatureCase{
  DEFAULT, 
  TANIERE, 
  PIEGE, 
  EAU
}
