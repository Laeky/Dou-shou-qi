

public enum Direction {
    AVANT,
    ARRIERE,
    DROITE,
    GAUCHE
}
