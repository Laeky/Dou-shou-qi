public enum Equipe{
	ROUGE, NOIR	
}
