public enum Espece{
    CHAT,
    TIGRE,
    LION,
    RAT,
    LEOPARD,
    CHIEN,
    LOUP,
    ELEPHANT
}